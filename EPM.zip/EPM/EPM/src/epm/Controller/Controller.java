package epm.Controller;

import epm.Event.EventHandler;
import epm.Handlers.FileHandler;
import epm.Property.Property;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.util.ArrayList;
import java.util.HashMap;
/**
 * @author AKSHAYAK
 * This class controls the main flow of the program. Execution of the application starts from here.
 */
public class Controller {
    public static HashMap<String,String> map=null;
     static final Logger LOGGER= Logger.getLogger(Controller.class.getName());
    public static void main(String[] args) {
       PropertyConfigurator.configure("./log4j.properties");
      map=Property.getProperties();
        LOGGER.debug(map.get("input"));
        FileHandler.inputs=map.get("input");
        FileHandler.processed=map.get("processed");
        while(true) {
            check(map.get("interval"));
        }
    }

    public static void check(String interval){
        ArrayList<String[]> data= FileHandler.accessFile();

        if(data==null){
            try {
                Thread.sleep(Integer.valueOf(interval)*1000);
                System.out.println("not started instantly");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            check(interval);
        }
else{
        EventHandler.handleEvents(data,map.get("db_user"),map.get("db_password"),map.get("db_service"),map.get("db_host"));
        FileHandler.moveFile();}


    }
}
