package epm.Property;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Properties;

/**
 * @author AKSHAYAK
 * This class is used to generate properties by parsing the key value pair from Files.properties file.
 */
public class Property {
    private static Properties prop = new Properties();
    private static InputStream input = null;
    public static HashMap<String,String> getProperties(){
        try {
            input=new FileInputStream("./File.properties");
            prop.load(input);
        } catch (IOException e) {
            e.printStackTrace();
        }
        HashMap<String,String> map = new HashMap<>();
        map.put("input",prop.getProperty("input"));
        map.put("processed",prop.getProperty("processed"));
        map.put("interval",prop.getProperty("interval"));
        map.put("db_user",prop.getProperty("db_user"));
        map.put("db_password",prop.getProperty("db_password"));
        map.put("db_service",prop.getProperty("db_service"));
        map.put("db_host",prop.getProperty("db_host"));
        return map;
    }
}
