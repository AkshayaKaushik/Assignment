package epm.DAO;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * @author AKSHAYAK
 * This class is used to handle all the database related transactions . Query for EVENT_RATE table , RATED_EVENT table and REJECTED_EVENT table is handle by this class.
 */
public class EventDAO {

     static final Logger LOGGER= Logger.getLogger(EventDAO.class.getName());
    public static EventRatePOJO getEventDetail(Connection connection, String event_type, String Date) {
        EventRatePOJO eventrate = new EventRatePOJO();
        StringBuffer query = new StringBuffer();

        try {

            Statement st = connection.createStatement();
            query.append("Select * from (SELECT * FROM event_rate where EVENT_TYPE='" + event_type + "' and to_date('" + Date + "','DD/MM/YYYY HH:MI:SS') > effective_date order by effective_date desc) where rownum=1");
            ResultSet rs = st.executeQuery(query.toString());

            while (rs.next()) {
                eventrate.setEVENT_TYPE(rs.getString(1));
                eventrate.setEFFECTIVE_DATE(rs.getDate(2));
                eventrate.setUOM(rs.getString(3));
                eventrate.setUNIT_AMOUNT(rs.getInt(4));
                eventrate.setUNIT_RATE(rs.getString(5));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return eventrate;
    }

    public static void setRateDetail(Connection connection, RatedEventPOJO rate) {
        String query = new String();
        PropertyConfigurator.configure("./log4j.properties");
        try {
            Statement st = connection.createStatement();
            query = ("Insert into RATED_EVENT_ASSIGN(EVENT_TYPE,TARGET_RESOURCE,EVENT_START_TIME,EVENT_UNIT_CONSUMED,TOTAL_CHARGE) values ('" + rate.getEVENT_TYPE() + "'," + rate.getTARGET_RESOURCE() +
                    ",to_date('" + rate.getEVENT_START_TIME() + "','DD/MM/YYYY HH:MI;SS')," + rate.getEVENT_UNIT_CONSUMED() + "," + rate.getTOTAL_CHARGE() + ")");

            int i = st.executeUpdate(query);
            LOGGER.debug("Successfully inserted value in Rated Event table see the int value = " + i);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public static void setRajectDetail(Connection connection, RejectedEventPOJO reject) {
        PropertyConfigurator.configure("./log4j.properties");
        String query = new String();
        try {
            Statement st = connection.createStatement();
            query=("Insert into REJECTED_EVENT_ASSIGN(EVENT_TYPE,TARGET_RESOURCE,EVENT_START_TIME,EVENT_UNIT_CONSUMED,REJECTION_REASON) values ('" + reject.getEVENT_TYPE() + "'," + reject.getTARGET_RESOURCE() +
                    ",to_date('" + reject.getEVENT_START_TIME() + "','DD/MM/YYYY HH:MI;SS'),"+ reject.getEVENT_UNIT_CONSUMED() + ",'" + reject.getREJECTION_REASON() + "')");
            int i = st.executeUpdate(query);
           LOGGER.debug("Successfully inserted value in Rejected Event table see the int value = " + i);
        }
        catch(SQLException e){
                e.printStackTrace();
            }



    }
}
