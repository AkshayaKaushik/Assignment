package epm.DAO;

public class RatedEventPOJO {
    private String EVENT_TYPE;
    private Long TARGET_RESOURCE;
    private String EVENT_START_TIME;
    private Long EVENT_UNIT_CONSUMED;
    private Double TOTAL_CHARGE;
    public RatedEventPOJO() {
    }

    public String getEVENT_TYPE() {
        return EVENT_TYPE;
    }

    public void setEVENT_TYPE(String EVENT_TYPE) {
        this.EVENT_TYPE = EVENT_TYPE;
    }

    public Long getTARGET_RESOURCE() {
        return TARGET_RESOURCE;
    }

    public void setTARGET_RESOURCE(Long TARGET_RESOURCE) {
        this.TARGET_RESOURCE = TARGET_RESOURCE;
    }

    public String getEVENT_START_TIME() {
        return EVENT_START_TIME;
    }

    public void setEVENT_START_TIME(String EVENT_START_TIME) {
        this.EVENT_START_TIME = EVENT_START_TIME;
    }

    public Long getEVENT_UNIT_CONSUMED() {
        return EVENT_UNIT_CONSUMED;
    }

    public void setEVENT_UNIT_CONSUMED(Long EVENT_UNIT_CONSUMED) {
        this.EVENT_UNIT_CONSUMED = EVENT_UNIT_CONSUMED;
    }

    public Double getTOTAL_CHARGE() {
        return TOTAL_CHARGE;
    }

    public void setTOTAL_CHARGE(Double TOTAL_CHARGE) {
        this.TOTAL_CHARGE = TOTAL_CHARGE;
    }
}
