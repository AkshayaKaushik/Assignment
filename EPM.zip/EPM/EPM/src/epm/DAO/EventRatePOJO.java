package epm.DAO;

import java.sql.Date;

public class EventRatePOJO {
    private String EVENT_TYPE;
    private Date EFFECTIVE_DATE;
    private String UOM;
    private Integer UNIT_AMOUNT;
    private String UNIT_RATE;
    public EventRatePOJO() {

    }

    public String getEVENT_TYPE() {
        return EVENT_TYPE;
    }

    public void setEVENT_TYPE(String EVENT_TYPE) {
        this.EVENT_TYPE = EVENT_TYPE;
    }

    public Date getEFFECTIVE_DATE() {
        return EFFECTIVE_DATE;
    }

    public void setEFFECTIVE_DATE(Date EFFECTIVE_DATE) {
        this.EFFECTIVE_DATE = EFFECTIVE_DATE;
    }

    public String getUOM() {
        return UOM;
    }

    public void setUOM(String UOM) {
        this.UOM = UOM;
    }

    public Integer getUNIT_AMOUNT() {
        return UNIT_AMOUNT;
    }

    public void setUNIT_AMOUNT(Integer UNIT_AMOUNT) {
        this.UNIT_AMOUNT = UNIT_AMOUNT;
    }

    public String getUNIT_RATE() {
        return UNIT_RATE;
    }

    public void setUNIT_RATE(String UNIT_RATE) {
        this.UNIT_RATE = UNIT_RATE;
    }
}


