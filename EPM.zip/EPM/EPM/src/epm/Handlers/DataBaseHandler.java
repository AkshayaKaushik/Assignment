package epm.Handlers;

import oracle.jdbc.OracleDriver;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * @author AKSHAYAK
 * This class is use to handle all the datbase connections. It generate the connection to the database and close the same when required.
 */
public class DataBaseHandler {
     static final Logger LOGGER= Logger.getLogger(DataBaseHandler.class.getName());
        private String user = null,pass = null,service=null,host=null;
    private String url = null;

    public DataBaseHandler(String user,String pass,String service,String host)
    {
        this.user=user;
        this.pass=pass;
        this.service=service;
        this.host=host;
    }
    public Connection getConnection(){
        PropertyConfigurator.configure("./log4j.properties");
        url="jdbc:oracle:thin:@"+host+":1521:"+service;
        Connection connection=null;
        try {
            DriverManager.registerDriver(new OracleDriver());
           connection = DriverManager.getConnection(url, user, pass);
            LOGGER.debug("creating the connection = "+connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return connection;
    }
    public void closeConnection( Connection connection){
        PropertyConfigurator.configure("./log4j.properties");
        try {
            connection.close();
            LOGGER.debug("closing connection = "+connection);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
