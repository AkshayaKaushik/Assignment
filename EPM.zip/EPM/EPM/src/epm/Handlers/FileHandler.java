package epm.Handlers;


import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Date;

/**
 * @author AKSHAYAK
 * This class is use to handle all the files related transaction. It is used to access the input file and move it to another loaction after processing.
 */
public class FileHandler {
     static final Logger LOGGER= Logger.getLogger(FileHandler.class.getName());
  public static String inputs=null;
    public static String processed=null;
  public static ArrayList<String[]> accessFile() {
      PropertyConfigurator.configure("./log4j.properties");
      String line;
      String cvsSplitBy = ",";
      ArrayList<String[]> list=new ArrayList<String[]>() ;
      File f=new File(inputs);
      if(f.exists()) {
          try (BufferedReader br = new BufferedReader(new FileReader(f))) {

              while ((line = br.readLine()) != null) {

                  // use comma as separator

                  String[] country = line.split(cvsSplitBy);
                  list.add(country);
              }

          } catch (IOException e) {
              e.printStackTrace();
          }
      }
      else
          list=null;

      return list;
  }
  public static void moveFile(){
      PropertyConfigurator.configure("./log4j.properties");
      Path temp = null;
      try {
          temp = Files.move(Paths.get(inputs),Paths.get(processed+new Date().getTime()+".txt"));
          if(temp != null) {
              LOGGER.debug("File renamed and moved successfully");
          } else
          {
              LOGGER.error("Failed to move the file");
          }
      } catch (IOException e) {
          e.printStackTrace();
      }


  }
}
