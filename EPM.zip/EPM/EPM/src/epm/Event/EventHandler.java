package epm.Event;

import epm.Handlers.DataBaseHandler;
import epm.DAO.EventDAO;
import epm.DAO.EventRatePOJO;
import epm.DAO.RatedEventPOJO;
import epm.DAO.RejectedEventPOJO;
import org.apache.log4j.BasicConfigurator;
import org.apache.log4j.Logger;

import java.sql.Connection;
import java.util.ArrayList;

/**
 * @author AKSHAYAK
 * This class is used to handle all the event transactions. it process all the events coming from csv file and store the result into database by calling the EVENT DAO class as per the logic.
 */
public class EventHandler {
     static final Logger LOGGER= Logger.getLogger(EventHandler.class.getName());
    public static void handleEvents(ArrayList<String[]> data, String user, String password, String service, String host) {
        BasicConfigurator.configure();
        DataBaseHandler handler = new DataBaseHandler(user, password, service, host);
        Connection connection = handler.getConnection();
        EventRatePOJO er = null;
        double total_charge;
        RatedEventPOJO rate=new RatedEventPOJO();
        RejectedEventPOJO reject =new RejectedEventPOJO();
        for (String arr[] : data) {
            er = EventDAO.getEventDetail(connection, arr[0], arr[2]);
            if (er.getUNIT_AMOUNT() != null) {
                rate.setEVENT_TYPE(arr[0]);rate.setEVENT_START_TIME(arr[2]);
                rate.setEVENT_UNIT_CONSUMED(Long.valueOf(arr[3])); rate.setTARGET_RESOURCE(Long.valueOf(arr[1]));
                total_charge= Integer.valueOf(arr[3]) / er.getUNIT_AMOUNT();
                rate.setTOTAL_CHARGE(total_charge);
                EventDAO.setRateDetail(connection,rate);
            } else {
                reject.setEVENT_TYPE(arr[0]);reject.setEVENT_START_TIME(arr[2]);
                reject.setEVENT_UNIT_CONSUMED(Long.valueOf(arr[3])); reject.setTARGET_RESOURCE(Long.valueOf(arr[1]));
                reject.setREJECTION_REASON("Cannot find the total charge as there is no effective date associated with for the current event");
                EventDAO.setRajectDetail(connection,reject);
            }
        }
        handler.closeConnection(connection);
    }
}
